import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : AppCompatActivity() {
    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            BluetoothApp(bluetoothAdapter = bluetoothAdapter, context = this)
        }
    }
}

@Composable
fun BluetoothApp(bluetoothAdapter: BluetoothAdapter?, context: Context) {
    var isBluetoothEnabled by remember { mutableStateOf(bluetoothAdapter?.isEnabled ?: false) }
    var pairedDevices by remember { mutableStateOf(bluetoothAdapter?.bondedDevices ?: setOf()) }
    var selectedDevice by remember { mutableStateOf<BluetoothDevice?>(null) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Bluetooth Status: ${if (isBluetoothEnabled) "Enabled" else "Disabled"}")

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            if (bluetoothAdapter != null && !bluetoothAdapter.isEnabled) {
                val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                context.startActivity(enableBtIntent)
            }
            isBluetoothEnabled = bluetoothAdapter?.isEnabled ?: false
        }) {
            Text("Enable Bluetooth")
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (isBluetoothEnabled) {
            Text("Paired Devices:")

            pairedDevices.forEach { device ->
                Button(onClick = {
                    selectedDevice = device
                    Toast.makeText(context, "Connecting to ${device.name}", Toast.LENGTH_SHORT).show()
                    // Handle Bluetooth connection here
                }) {
                    Text("${device.name} (${device.address})")
                }
            }
        }
    }
}
